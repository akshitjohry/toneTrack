// Minio Configuration
const minioClient = new Minio.Client({
    endPoint: 'minio',
    port: 9000,
    useSSL: false,
    accessKey: 'rootuser',
    secretKey: 'rootpass123',
});

// Chart Configuration
const ctx = document.getElementById('myChart').getContext('2d');
const myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: [],
        datasets: [{
            label: 'Minio Data',
            data: [],
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 2,
            fill: false,
        }],
    },
    options: {
        scales: {
            x: {
                type: 'linear',
                position: 'bottom',
            },
            y: {
                type: 'linear',
                position: 'left',
            },
        },
    },
});

// Function to fetch data from Minio and update the chart
async function fetchDataAndUpdateChart() {
    try {
        // Replace 'your-bucket' and 'your-object' with your Minio bucket and object details
        const dataStream = await minioClient.getObject('output', 'your-object');

        let data = '';
        dataStream.on('data', (chunk) => {
            data += chunk;
        });

        dataStream.on('end', () => {
            // Parse the data (adjust accordingly based on your data format)
            const parsedData = JSON.parse(data);

            // Update chart labels and data
            myChart.data.labels = parsedData.labels;
            myChart.data.datasets[0].data = parsedData.values;

            // Update the chart
            myChart.update();
        });
    } catch (error) {
        console.error('Error fetching data from Minio:', error);
    }
}

// Fetch and update data initially
fetchDataAndUpdateChart();

// Optionally, set up an interval to periodically update the chart
// setInterval(fetchDataAndUpdateChart, 60000); // Update every minute (adjust as needed)
